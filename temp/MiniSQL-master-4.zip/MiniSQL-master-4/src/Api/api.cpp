#include<string>
#include<iostream>
#include "table.h"
using namespace std;


int insertValues(Table table, vector<string> values){


}


