#ifndef __DATABASE_H__
#define __DATABASE_H__

struct Database{
	string db_name;
};


#endif
